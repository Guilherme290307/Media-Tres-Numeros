let Numero1 = document.querySelector("#Numero1");
let Numero2 = document.querySelector("#Numero2");
let Numero3 = document.querySelector("#Numero3");
let btCalcularMedias = document.querySelector("#btCalcularMedias");
let Resultado = document.querySelector("#Resultado");

function Calcular() {
  let num1 = Number(Numero1.value);
  let num2 = Number(Numero2.value);
  let num3 = Number(Numero3.value);

  let mediaAritmetica = (num1 + num2 + num3) / 3;

  let somaValoresPesos = (num1 * 3) + (num2 * 2) + (num3 * 5);
  let somaPesos = 3 + 2 + 5;
  let mediaPonderada = somaValoresPesos / somaPesos;

  let somaMedias = mediaAritmetica + mediaPonderada;

  let mediaDasMedias = somaMedias / 2;

  Resultado.innerHTML = "Media Aritmetica:" + mediaAritmetica + "<br>" + 
  "Media Ponderada:" + mediaPonderada + "<br>" + 
  "Soma das Medias:" + somaMedias + "<br>" + 
  "Media das Medias:" + mediaDasMedias;
}

btCalcularMedias.onclick = function() {
    Calcular();
}